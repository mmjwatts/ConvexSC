#!/bin/bash
sudo wpa_supplicant -c/etc/wpa_supplicant/wpa_supplicant.conf -iwlan0 -f/home/pi/stockcube/logs/wifi/wpa_supp.txt
