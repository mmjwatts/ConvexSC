#/bin/bash

sudo /home/pi/stockcube/led-image-viewer --led-rows=64 --led-cols=192 --led-rgb-sequence="BGR" --led-pixel-mapper="Rotate:90" --led-brightness=70 /home/pi/stockcube/WelcomeScreen.bmp
